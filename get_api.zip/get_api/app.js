require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { parseCSV, writeCSV } = require('./helpers/csvHelper');

const app = express();
const upload = multer({ dest: 'uploads/' });

const PORT = 3000;
const PAYMENTS_API_URL = 'https://api.sandbox.checkout.com/payments';
const API_KEY = process.env.CHECKOUT_API_KEY;
const OUTPUT_DIR = path.join(__dirname, 'output');
const PUBLIC_DIR = path.join(__dirname, 'public');

let processing = false; // Global variable to track if a process is ongoing
let recordCount = 0; // Global variable for record counter

// Validate API Key on startup
if (!API_KEY) {
    console.error('Error: API Key is missing. Please set CHECKOUT_API_KEY in your .env file.');
    process.exit(1); // Exit the app if the API key is missing
}

// Log the API Key (masked for security) for debugging purposes
console.log(`Using API Key: ${API_KEY.slice(0, 6)}********`);

// Serve static files from the public directory
app.use(express.static(PUBLIC_DIR));

// Ensure the output directory exists
if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR);
}

// Utility function to add delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Route: Default route serves index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Route: Get record count for the frontend
app.get('/record-count', (req, res) => {
    res.json({ recordCount });
});

// Route: Process input file and append metadata
app.post('/upload', upload.single('csvFile'), async (req, res) => {
    const inputFileName = req.file.originalname; // Extract the input file name
    const filePath = req.file.path;
    const outputFile = path.join(OUTPUT_DIR, inputFileName); // Use the input file name for the output file

    console.log(`Received file: ${inputFileName}`);
    processing = true; // Start processing
    recordCount = 0; // Reset record counter
    try {
        const rows = await parseCSV(filePath);

        // Ensure headers include UDF fields
        const headers = new Set(Object.keys(rows[0]));
        for (let i = 1; i <= 5; i++) {
            headers.add(`UDF ${i}`);
        }

        const results = [];

        for (let i = 0; i < rows.length; i++) {
            if (!processing) break; // Stop if cancel is triggered
            const row = rows[i];
            const paymentId = row['Payment ID'];
            if (!paymentId) continue;

            const url = `${PAYMENTS_API_URL}/${paymentId}`;
            console.log(`Processing record ${i + 1}/${rows.length} (Payment ID: ${paymentId})`);
            recordCount = i + 1; // Update record count
            try {
                // Explicitly set the Authorization header
                const response = await axios.get(url, {
                    headers: { Authorization: API_KEY },
                });

                const metadata = response.data.metadata || {};

                // Dynamically populate UDF fields
                const udfKeys = Object.keys(metadata);
                for (let j = 0; j < udfKeys.length && j < 5; j++) {
                    const udfField = `UDF ${j + 1}`;
                    row[udfField] = metadata[udfKeys[j]];
                }
            } catch (err) {
                if (err.response && err.response.status === 401) {
                    console.error(
                        `401 Unauthorized: Please check your API key or permissions for Payment ID: ${paymentId}`
                    );
                } else {
                    console.error(
                        `Error fetching payment details for ${paymentId}: ${err.message}`
                    );
                }
            }

            results.push(row);
            await delay(1000);
        }

        if (processing) {
            await writeCSV(outputFile, results, Array.from(headers));
            res.send(`
                <html>
                <head>
                    <link rel="stylesheet" href="/style.css">
                </head>
                <body>
                    <div class="container">
                        <h1>File Generated</h1>
                        <p><a href="/download?file=${inputFileName}" class="button">Download File</a></p>
                        <button onclick="location.href='/'" class="button secondary">Go Back</button>
                    </div>
                </body>
                </html>
            `);
        }
    } finally {
        processing = false; // Reset processing flag
        recordCount = 0; // Reset record counter
        fs.unlinkSync(filePath);
    }
});

// Route: Cancel current process
app.post('/cancel', (req, res) => {
    processing = false; // Stop the ongoing process
    res.status(200).send('Process canceled');
});

// Route: Download output file
app.get('/download', (req, res) => {
    const file = req.query.file;
    const filePath = path.join(OUTPUT_DIR, file);
    res.download(filePath, (err) => {
        if (err) res.status(500).send('Error downloading the file.');
    });
});

// Start server on port 3000
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
