const fs = require('fs');
const csv = require('fast-csv');

/**
 * Parse a CSV file and extract rows as objects.
 * @param {string} filePath - Path to the uploaded CSV file.
 * @returns {Promise<Array<object>>} - A promise that resolves to an array of rows (objects).
 */
const parseCSV = (filePath) => {
    return new Promise((resolve, reject) => {
        const rows = [];
        console.log(`Parsing CSV file: ${filePath}`);

        fs.createReadStream(filePath)
            .pipe(csv.parse({ headers: true }))
            .on('data', (row) => {
                rows.push(row);
            })
            .on('end', () => {
                console.log(`Finished parsing CSV. Rows extracted: ${rows.length}`);
                resolve(rows);
            })
            .on('error', (err) => {
                console.error('Error parsing CSV file:', err.message);
                reject(err);
            });
    });
};

/**
 * Write data to a CSV file with dynamic headers.
 * @param {string} filePath - Path to the output CSV file.
 * @param {Array<object>} data - Data to write to the CSV file.
 * @returns {Promise<void>}
 */
const writeCSV = (filePath, data) => {
    return new Promise((resolve, reject) => {
        if (data.length === 0) {
            console.error('No data to write to CSV.');
            reject(new Error('No data to write to CSV.'));
            return;
        }

        // Dynamically infer headers from the first row
        const headers = Object.keys(data[0]);
        console.log(`Writing CSV with headers: ${headers.join(', ')}`);

        const writeStream = fs.createWriteStream(filePath);

        csv.write(data, { headers: true })
            .pipe(writeStream)
            .on('finish', () => {
                console.log(`CSV written successfully to ${filePath}`);
                resolve();
            })
            .on('error', (err) => {
                console.error('Error writing to CSV:', err.message);
                reject(err);
            });
    });
};

module.exports = { parseCSV, writeCSV };
