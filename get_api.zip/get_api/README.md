Checkout.com Metadata Appender
This application processes CSV files containing payment IDs, performs API requests to the Checkout.com platform to fetch payment metadata, and appends the metadata fields to the corresponding rows in the CSV. The updated file is downloadable with the same name as the input file.

Features
Drag-and-Drop File Upload: Intuitive interface to upload files.
Metadata Retrieval: Dynamically fetches and appends up to 5 metadata fields (e.g., UDF 1 to UDF 5) from the API response.
Real-Time Progress Tracking: Displays a progress bar while processing records.
Cancel Processing: Stop the process and reset the interface with a single click.
Output File Naming: The output file retains the same name as the input file for easy identification.
Requirements
Software Requirements
Node.js: Version 14 or higher.
npm: Installed along with Node.js.
Checkout.com API Key: Available from the Checkout.com Dashboard.
Installation

npm install
Set Environment Variables: Create a .env file in the root directory and add your Checkout.com API key:

CHECKOUT_API_KEY=sk_sbox_your_secret_key
Replace sk_sbox_your_secret_key with your actual API key.

Ensure Directory Structure: Verify the following folders exist (they will be created automatically if missing):

uploads: Temporary storage for uploaded files.
output: Stores processed files for download.